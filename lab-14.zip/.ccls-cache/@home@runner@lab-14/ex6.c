#include <stdio.h>

int divisiveis(int arr[], int tam, int x) {
    if (tam == 0) {
        return 1;
    } else {
        return (arr[tam - 1] % x == 0) && divisiveis(arr, tam - 1, x);
    }
}

int main() {
    int numeros[] = {6, 12, 18, 24};
    int resultado = divisiveis(numeros, 4, 6);
    printf("%s\n", resultado ? "true" : "false");
    return 0;
}
