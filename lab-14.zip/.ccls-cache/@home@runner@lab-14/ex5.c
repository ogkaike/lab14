#include <stdio.h>

float soma_array(float arr[], int tam) {
    if (tam == 0) {
        return 0;
    } else {
        return arr[tam - 1] + soma_array(arr, tam - 1);
    }
}

int main() {
    float numeros[] = {1.5, 2.5, 3.5, 4.5};
    float resultado = soma_array(numeros, 4);
    printf("%f\n", resultado);
    return 0;
}
